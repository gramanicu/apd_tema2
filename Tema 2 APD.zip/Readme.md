# APD, 2nd Homework - "Traffic simulator"

The second homework for the Parallel & Distributed Algorithms Course ([The problem statement](tema%202%20-%20enunt.pdf))

## Problem solution

© 2020 Grama Nicolae
